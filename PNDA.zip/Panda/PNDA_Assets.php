<?php
require_once('DB_Config.php');
/*
Konstante werden Eingebunden über require_once 
require_once bietet Mehrfacheinbindung der selben Datei 
*/
$db_con = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_DB); //DB Verbindung aufbauen 
mysqli_set_charset($db_con, "utf8"); //Charset ist  wegen Umlaute oder Sonderzeichen 
session_start();
/*Session um Formulardaten auf mehreren Pages zu verwenden 
KundenID wird auf dieser Page verarbeitet
*/
$KundenID=$_SESSION['KundenID'];
$firstname = $_SESSION["firstname"];
$lastname  = $_SESSION["lastname"];
$street  = $_SESSION["street"];
$postalcode  = $_SESSION["postalcode"];
$location = $_SESSION["location"];
//Alle Formulardaten werden eingelesen aus der Sitzung 


if($db_con){ //Ob Verbindung hergestellt werden kann
    echo'Es Geht';
    $ins="INSERT INTO pnda_assets (ID) VALUES('$KundenID')"; 
    /*
    Die KundenID wird am Anfang eingetragen, während der Auswertung der Checkboxen nicht möglich 
    */
    mysqli_query($db_con,$ins);
if(isset($_POST["asset"])){ //Ob Checkbox aktiviert wurde
    $checked=$_POST["asset"]; //Array der Checboxen, welche versendet wurden wird in $checked gespeichert 
    foreach($checked as $checkedbox){ //Iterartion durch alle angewählten Checboxen 
        $up = "UPDATE pnda_assets SET $checkedbox = TRUE WHERE ID = '$KundenID'"; 
        mysqli_query($db_con,$up);
         //Update Loop damit alle ausgewählten Checkboxen in die Datenbank geschrieben werden
    }
    $ins_view="INSERT INTO pnda_view (ID, Vorname, Nachname, Straße, PLZ, Ort) VALUES('$KundenID','$firstname','$lastname','$street','$postalcode','$location')";
    mysqli_query($db_con,$ins_view);
    foreach($checked as $checkedbox){ //Iterartion durch alle angewählten Checboxen 
        $up = "UPDATE pnda_view SET $checkedbox = TRUE WHERE ID = '$KundenID'"; 
        mysqli_query($db_con,$up);
         //Update Loop damit alle ausgewählten Checkboxen in die Datenbank geschrieben werden
    }
    mysqli_close($db_con);
        session_destroy();
    header('Location:http://127.0.0.1/Panda/PNDA_DONE.html');
}
    else{
        mysqli_close($db_con);
        session_destroy();
        header('Location:http://127.0.0.1/Panda/PNDA_DONE.html');
        //Verbindungen werden geschlossen und Weiterleitung auf potenzielle mainpage 
    }
}
else{
session_destroy();
die('Verbindung kann nicht aufgebaut werden');

//Verbindungen werden geschlossen
}


?>