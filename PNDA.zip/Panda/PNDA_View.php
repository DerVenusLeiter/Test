<?php 
require_once('DB_Config.php');
$select ="select * from pnda_view"; //Kompletter select aus pnda_view
$db_con = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DB); //DB Verbindung aufbauen 
mysqli_set_charset($db_con, "utf8"); //Charset ist  wegen Umlaute oder Sonderzeichen 

$view=mysqli_query($db_con,$select); //Zugriff auf DB 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   
</head>
<body>
  <div id="table-view">
    <table border="1">
        <thead>
            <th>
                ID
            </th>
            <th>
                Vorname
            </th>
            <th>
                Nachname
            </th>
            <th>
                Straße
            </th>
            <th>
                PLZ
            </th>
            <th>
                Ort
            </th>
            <th>
                Versicherung
            </th>
            <th>
                Geldanlage
            </th>
            <th>
                Aktien
            </th>
            <th>
                ETF
            </th>
            <th>
                NFT
            </th>
            <th>
                Gold
            </th>
            <th>
                Rohstoffe
            </th>
            <th>
                Status
            </th>
            <th>
            Status Ändern
        </th>
        </thead>
        <tbody>
                <?php
                while($res=mysqli_fetch_array($view)){
                    echo'<tr>';
                    echo"<td>".$res["ID"]."</td>";
                    echo"<td>".$res["Vorname"]."</td>";
                    echo"<td>".$res["Nachname"]."</td>";
                    echo"<td>".$res["Straße"]."</td>";
                    echo"<td>".$res["PLZ"]."</td>";
                    echo"<td>".$res["Ort"]."</td>";
                    echo"<td>".$res["Versicherung"]."</td>";
                    echo"<td>".$res["Geldanlage"]."</td>";
                    echo"<td>".$res["Aktien"]."</td>";
                    echo"<td>".$res["ETF"]."</td>";
                    echo"<td>".$res["NFT"]."</td>";
                    echo"<td>".$res["Gold"]."</td>";
                    echo"<td>".$res["Rohstoffe"]."</td>";
                    echo"<td id='state" . $res['ID'] . "'>".$res["State"]."</td>";
                    echo '<td><select id="selectedStatus" onchange="updateStatus(this, ' . $res["ID"] . ')">'; 
                    //Onchange Ereignis, this bezieht sich auf das akutelle Select feld
                    //Option Tag mit dem Value "Offen" kann noch hinzugefügt werden bei bedarf

                    echo '<option value=" ">Bitte wählen</option>'; // Dummy Field
                    echo '<option value="In Bearbeitung">In Bearbeitung</option>';
                    echo '<option value="Erledigt">Erledigt</option>';
                    echo '</select></td>';
                    //Loop durch komplettes select 
                }
            ?>
                </td>
                <script>
  function updateStatus(selectedElement, recordID) {
    let newStatus = selectedElement.value; //Aktuelle ID und State wird gespeichert
    if(newStatus!=" ") document.getElementById("state"+recordID).innerHTML=newStatus;
    //Damit kein Leer String entsteht wenn man wieder das Dummy Feld auswählt
    
  
    const data = {
      ID: recordID,
      Status: newStatus
    };

  //Objekt aus ID und State
    fetch('PNDA_Update_view.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json' 
      },
      body: JSON.stringify(data)
      //JSON wird erstellt und ans PHP-Skript übertragen  
    })
   
  
  }
</script>
        </tbody>
    </table>
</body>
</html>