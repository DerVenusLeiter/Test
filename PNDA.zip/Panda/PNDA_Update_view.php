<?php
require_once('DB_Config.php');
/*
Konstante werden Eingebunden über require_once 
require_once bietet Mehrfacheinbindung der selben Datei 
*/
$db_con = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DB); //DB Verbindung aufbauen 
mysqli_set_charset($db_con, "utf8"); //Charset ist  wegen Umlaute oder Sonderzeichen 
$data_view=json_decode(file_get_contents("php://input"),true);
//JSON wird decodet $data_view erhält die KEY-VALUE PAIRS 
if($data_view!==null){
    
$ID=$data_view["ID"];
$state=$data_view["Status"];
//Values aus dem Objekt extrahieren
$update_view="UPDATE pnda_view SET State='$state' WHERE ID='$ID'";
mysqli_query($db_con,$update_view);
//SQL Befehl wird ausgeführt
}

?>