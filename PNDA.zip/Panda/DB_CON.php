<?php
require_once('DB_Config.php');
/*
Konstante werden Eingebunden über require_once 
require_once bietet Mehrfacheinbindung der selben Datei 
*/
$db_con = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DB); //DB Verbindung aufbauen 
mysqli_set_charset($db_con, "utf8"); //Charset ist  wegen Umlaute oder Sonderzeichen 

$firstname = $_POST["firstname"];
$lastname = $_POST["lastname"];
$street = $_POST["street"];
$postalcode = $_POST["postalcode"];
$location = $_POST["location"];
//Formulardaten einlesen 
session_start();
//Session um Formulardaten auf mehreren Pages zu verwenden 
if ($db_con) {
    echo 'Connection established';
    $ins = "INSERT INTO pnda_customers (Vorname, Nachname, Straße, PLZ, Ort) VALUES('$firstname','$lastname','$street','$postalcode','$location')";
    if (!mysqli_query($db_con, $ins)) {
        echo "Fehler beim Eintragen der Daten";
        mysqli_close($db_con);
        //Verbindung Trennen sobald Insert fehlschlägt 
    }
    $sel = "SELECT ID FROM pnda_customers WHERE Vorname='$firstname' AND Nachname='$lastname' AND Straße='$street'" ;
    $result = mysqli_query($db_con, $sel);
    $result = mysqli_fetch_assoc($result);
    $result = $result["ID"];
    $_SESSION['KundenID'] = $result;
    $_SESSION["firstname"] = $_POST["firstname"];
    $_SESSION["lastname"] = $_POST["lastname"];
    $_SESSION["street"] = $_POST["street"];
    $_SESSION["postalcode"] = $_POST["postalcode"];
    $_SESSION["location"] = $_POST["location"];
    //Alle Formular-Daten werden in einer Sessions Gespeichert 
    /*
    Kunden ID wird aus der Datenbank geholt.
    Relevant für "PNDA_Assets.php", damit der Insert des Foreign Key erfolgen kann
    */


    header('Location:http://127.0.0.1/Panda/PNDA_ASSETS.html');
    //Weiterleitung auf die "PNDA_ASSETS.html seite ohne zusätzliche Infos im Header 
} else {
    session_destroy();
    die('Connection denied');

    //Falls keine Verbindung mit der DB aufgebaut werden kann 
}
?>