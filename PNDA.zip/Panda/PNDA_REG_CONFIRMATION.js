//EventListenner, damit die Abfrage erfolgt, bevor das HTML gerendert wird 
document.addEventListener('DOMContentLoaded',function(){
    var check=confirm("Wollen Sie beraten werden?");
    if(!check){
        window.location.href="http://127.0.0.1/Panda/PNDA_DONE.html";
    }
})